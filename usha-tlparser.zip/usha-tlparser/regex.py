import datetime

from RegexGenerator import RegexGenerator

myRegexGenerator = RegexGenerator("Time Log:")

print(myRegexGenerator.get_regex())
